"""Native GPQA mapper/solver/scorer/log path with invented rows and MockLLM only."""
import importlib
import json
from pathlib import Path
import sys
from copy import deepcopy
from itertools import product
from types import SimpleNamespace

sys.path.insert(0, "/opt/ptb-gpqa")
import task as profile
import official_evidence as evidence
from inspect_ai import Task, eval as inspect_eval
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.model import ModelOutput
from inspect_ai.scorer import choice
from inspect_ai.solver import multiple_choice
from inspect_ai.solver._multiple_choice import parse_answers
from inspect_ai._util.content import ContentText, ContentReasoning

parser_cases = 0
for prefix, answer, suffix in product(
    ["ANSWER: ", "answer: ", "Reasoning. ANSWER: ", "ANSWER:\t", "ANSWER\n: ", "No answer "],
    ["A", "B", "C", "D", "a", "b", "E", "1", "A,B", "A B", "AB", "A and B", "", " A ", "A_", "Ａ"],
    ["", ".", "\n", " trailing", "\nANSWER: D", "!", ". More text"],
):
    completion = prefix + answer + suffix
    state = SimpleNamespace(output=SimpleNamespace(completion=completion), choices=[None] * 4)
    native = ", ".join(sorted(parse_answers(state, False)))
    assert evidence.parse_single_answer(completion) == native, repr(completion)
    parser_cases += 1
assert evidence.parse_single_answer("") == ""

root = Path("/home/ben")
rows = [{"Record ID": f"invented-{i}",
         "Question": f"INVENTED-Q-{i}\n" + "Synthetic context, not a benchmark question. " * 30,
         "Correct Answer": "duplicate" if i == 1 else "right",
         "Incorrect Answer 1": "duplicate" if i == 1 else "wrong-one",
         "Incorrect Answer 2": "wrong-two", "Incorrect Answer 3": "wrong-three"}
        for i in range(7)]
permutations = set()
for seed in range(300):
    native = MemoryDataset([Sample(**profile.source_record(row)) for row in rows])
    native.shuffle_choices(seed=seed)
    recorded = profile.prepare_samples(rows, seed=seed)
    assert [(s.choices, s.target) for s in recorded] == [(s.choices, s.target) for s in native]
    permutations.add(tuple(recorded[1].metadata["gpqa_choice_positions"]))
assert len(permutations) == 24

samples = profile.prepare_samples(rows)
assert all(sample.metadata["gpqa_shuffle_seed"] is None for sample in samples)
fake_profile = {"source_sha256": "0" * 64, "rows": 7}
contract = profile.selection_contract(samples, fake_profile, "explicitly-synthetic-profile")
invocation = {"attempt_id": "native-gpqa-synthetic", "model": "mockllm/model",
              "max_tokens": 64, "max_connections": 6, "formal": False,
              "scope": "invented-rows-no-benchmark-no-real-model"}
with (root / "request.json").open("x") as stream:
    json.dump({"contract": contract, "invocation": invocation}, stream, indent=2)
    stream.write("\n")

def mock_output(input, *_):
    prompt = input[-1].text
    index = next(i for i in range(7) if f"INVENTED-Q-{i}\n" in prompt)
    if index == 0:
        text = "Reasoning about an invented fixture.\nANSWER: " + samples[index].target
    elif index == 1:
        # Choose the incorrect original option with the identical text.
        text = "ANSWER: " + "ABCD"[samples[index].metadata["gpqa_choice_positions"].index(1)]
    elif index == 2:
        text = "ANSWER: " + next(letter for letter in "ABCD" if letter != samples[index].target)
    elif index == 3:
        text = "No formatted answer in this invented case."
    elif index == 4:
        text = "ANSWER: " + samples[index].target.lower()
    elif index == 5:
        text = ""
    else:
        text = [ContentReasoning(reasoning="Synthetic hidden reasoning, not an answer."),
                ContentText(text="Invented split content."), ContentText(text="ANSWER: E")]
    return ModelOutput.from_content(model="mockllm/model", content=text)

task = Task(name="gpqa_main", dataset=MemoryDataset(samples), epochs=1,
            solver=multiple_choice(cot=True), scorer=choice(),
            metadata={"ptb_invocation": invocation, "ptb_selection_sha256": evidence.digest(contract)})
logs = inspect_eval(task, model="mockllm/model", model_args={"custom_outputs": mock_output},
                    max_tokens=64, max_connections=6, log_samples=True, log_buffer=1,
                    log_dir=str(root / "logs"), log_format="json", log_realtime=False,
                    score_display=False, fail_on_error=True)
assert len(logs) == 1
raw_path = Path(logs[0].location)
raw = evidence.strict_json(raw_path.read_bytes())
summary_rows = []
for sample in raw["samples"]:
    events = [event for event in sample["events"] if event.get("event") == "model"]
    summary_rows.append({"id": sample["id"], "score": sample["scores"]["choice"]["value"],
                         "answer": sample["scores"]["choice"]["answer"], "target": sample["target"],
                         "model_events": len(events), "event_configs": [event["config"] for event in events],
                         "event_models": [event["model"] for event in events],
                         "event_user_attachment": [[message["content"].startswith("attachment://")
                             for message in event["input"] if message["role"] == "user"] for event in events]})
    assert all(event["config"]["max_tokens"] == 64 for event in events)
summary = {"image_label": sys.argv[1], "status": raw["status"], "native_task": raw["eval"]["task"],
           "rows": summary_rows, "native_seed_equivalence_cases": 300,
           "original_option_permutations_covered": len(permutations),
           "actual_evaluation_randomization_seed": None,
           "native_single_answer_differential_cases": parser_cases,
           "benchmark_data_loaded": False, "real_model_called": False,
           "raw_log": str(raw_path)}
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
published = evidence.publish_metrics(log_path=raw_path, metrics_path=root / "metrics.json",
                                    contract=contract, invocation=invocation)
assert published["accuracy"] == 1 / 7
assert evidence.validate_published(root / "metrics.json", expected_contract=contract,
                                   expected_invocation=invocation)["scored_samples"] == 7
rejected = []
for corruption in ("coherent-wrong-output", "missing-outputs"):
    changed = deepcopy(raw)
    sample = changed["samples"][0]
    if corruption == "missing-outputs":
        sample.pop("output")
        for event in sample["events"]:
            if event.get("event") == "model":
                event.pop("output", None)
    else:
        wrong = "ANSWER: " + next(letter for letter in "ABCD" if letter != sample["target"])
        outputs = [sample["output"]] + [event["output"] for event in sample["events"] if event.get("event") == "model"]
        for output in outputs:
            output["completion"] = wrong
            output["choices"][0]["message"]["content"] = wrong
        sample["messages"][-1]["content"] = wrong
        sample["scores"]["choice"]["explanation"] = wrong
    try:
        evidence.validate_log(changed, contract, invocation)
    except evidence.EvidenceError as error:
        rejected.append({"case": corruption, "rejected": True, "reason": str(error)})
    else:
        raise AssertionError(corruption + " was accepted")
summary["score_binding_negative_cases"] = rejected
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("NATIVE GPQA SYNTHETIC CONTRACT PASSED")
