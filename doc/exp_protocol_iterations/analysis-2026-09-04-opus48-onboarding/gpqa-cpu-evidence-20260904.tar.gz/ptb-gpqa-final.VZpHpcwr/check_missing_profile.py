"""Negative CLI admission check; no benchmark or model may be loaded."""
import json
from pathlib import Path
import subprocess
import sys

root = Path("/home/ben")
result = subprocess.run([sys.executable, "/opt/ptb-gpqa/evaluate.py", "--limit", "-1",
    "--model-path", "/home/ben/no-model-should-not-be-loaded",
    "--json-output-file", "/home/ben/missing-profile/metrics.json"], capture_output=True, text=True, check=False)
(root / "missing-profile.stdout").write_text(result.stdout)
(root / "missing-profile.stderr").write_text(result.stderr)
assert result.returncode != 0 and "data_provenance.json" in result.stderr
assert "resolve_local_model" not in result.stderr
assert not (root / "missing-profile/metrics.json").exists()
assert not list((root / "missing-profile").glob("official_eval/*/inspect/*"))
record = {"image_label": sys.argv[1], "exit_code": result.returncode,
          "missing_data_profile_rejected_before_model": True,
          "metrics_published": False, "inspect_model_log_created": False,
          "benchmark_data_loaded": False, "model_called": False}
(root / "missing-profile-check.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
