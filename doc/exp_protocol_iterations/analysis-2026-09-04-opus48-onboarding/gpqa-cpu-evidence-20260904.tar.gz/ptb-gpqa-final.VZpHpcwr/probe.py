"""Native GPQA mapper/solver/scorer/log path with invented rows and MockLLM only."""
import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/opt/ptb-gpqa")
import task as profile
import official_evidence as evidence
from inspect_ai import Task, eval as inspect_eval
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.model import ModelOutput
from inspect_ai.scorer import choice
from inspect_ai.solver import multiple_choice

root = Path("/home/ben")
rows = [{"Record ID": f"invented-{i}",
         "Question": f"INVENTED-Q-{i}\n" + "Synthetic context, not a benchmark question. " * 30,
         "Correct Answer": "duplicate" if i == 1 else "right",
         "Incorrect Answer 1": "duplicate" if i == 1 else "wrong-one",
         "Incorrect Answer 2": "wrong-two", "Incorrect Answer 3": "wrong-three"}
        for i in range(5)]
permutations = set()
for seed in range(300):
    native = MemoryDataset([Sample(**profile.source_record(row)) for row in rows])
    native.shuffle_choices(seed=seed)
    recorded = profile.prepare_samples(rows, seed=seed)
    assert [(s.choices, s.target) for s in recorded] == [(s.choices, s.target) for s in native]
    permutations.add(tuple(recorded[1].metadata["gpqa_choice_positions"]))
assert len(permutations) == 24

samples = profile.prepare_samples(rows)
assert all(sample.metadata["gpqa_shuffle_seed"] is None for sample in samples)
fake_profile = {"source_sha256": "0" * 64, "rows": 5}
contract = profile.selection_contract(samples, fake_profile, "explicitly-synthetic-profile")
invocation = {"attempt_id": "native-gpqa-synthetic", "model": "mockllm/model",
              "max_tokens": 64, "max_connections": 6, "formal": False,
              "scope": "invented-rows-no-benchmark-no-real-model"}
with (root / "request.json").open("x") as stream:
    json.dump({"contract": contract, "invocation": invocation}, stream, indent=2)
    stream.write("\n")

def mock_output(input, *_):
    prompt = input[-1].text
    index = next(i for i in range(5) if f"INVENTED-Q-{i}\n" in prompt)
    if index == 0:
        text = "Reasoning about an invented fixture.\nANSWER: " + samples[index].target
    elif index == 1:
        # Choose the incorrect original option with the identical text.
        text = "ANSWER: " + "ABCD"[samples[index].metadata["gpqa_choice_positions"].index(1)]
    elif index == 2:
        text = "ANSWER: " + next(letter for letter in "ABCD" if letter != samples[index].target)
    elif index == 3:
        text = "No formatted answer in this invented case."
    else:
        text = "ANSWER: " + samples[index].target.lower()
    return ModelOutput.from_content(model="mockllm/model", content=text)

task = Task(name="gpqa_main", dataset=MemoryDataset(samples), epochs=1,
            solver=multiple_choice(cot=True), scorer=choice(),
            metadata={"ptb_invocation": invocation, "ptb_selection_sha256": evidence.digest(contract)})
logs = inspect_eval(task, model="mockllm/model", model_args={"custom_outputs": mock_output},
                    max_tokens=64, max_connections=6, log_samples=True, log_buffer=1,
                    log_dir=str(root / "logs"), log_format="json", log_realtime=False,
                    score_display=False, fail_on_error=True)
assert len(logs) == 1
raw_path = Path(logs[0].location)
raw = evidence.strict_json(raw_path.read_bytes())
summary_rows = []
for sample in raw["samples"]:
    events = [event for event in sample["events"] if event.get("event") == "model"]
    summary_rows.append({"id": sample["id"], "score": sample["scores"]["choice"]["value"],
                         "answer": sample["scores"]["choice"]["answer"], "target": sample["target"],
                         "model_events": len(events), "event_configs": [event["config"] for event in events],
                         "event_models": [event["model"] for event in events],
                         "event_user_attachment": [[message["content"].startswith("attachment://")
                             for message in event["input"] if message["role"] == "user"] for event in events]})
    assert all(event["config"]["max_tokens"] == 64 for event in events)
summary = {"image_label": sys.argv[1], "status": raw["status"], "native_task": raw["eval"]["task"],
           "rows": summary_rows, "native_seed_equivalence_cases": 300,
           "original_option_permutations_covered": len(permutations),
           "actual_evaluation_randomization_seed": None,
           "benchmark_data_loaded": False, "real_model_called": False,
           "raw_log": str(raw_path)}
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
published = evidence.publish_metrics(log_path=raw_path, metrics_path=root / "metrics.json",
                                    contract=contract, invocation=invocation)
assert published["accuracy"] == .2
assert evidence.validate_published(root / "metrics.json", expected_contract=contract,
                                   expected_invocation=invocation)["scored_samples"] == 5
print("NATIVE GPQA SYNTHETIC CONTRACT PASSED")
