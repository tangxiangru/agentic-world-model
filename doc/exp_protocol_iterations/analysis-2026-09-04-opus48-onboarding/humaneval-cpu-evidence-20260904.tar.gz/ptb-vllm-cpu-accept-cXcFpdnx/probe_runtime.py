"""Read only interpreter/package/source metadata; no model or dataset imports."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import shutil
import sys
import sysconfig

packages = {}
for name in ("inspect_ai", "inspect_evals", "datasets", "numpy", "vllm", "transformers", "torch"):
    try:
        packages[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        packages[name] = None
files = {}
for package, names in {
    "inspect_ai": ["inspect_ai/util/_sandbox/environment.py", "inspect_ai/util/_sandbox/registry.py", "inspect_ai/util/_subprocess.py"],
    "inspect_evals": ["inspect_evals/humaneval/humaneval.py"],
}.items():
    distribution = importlib.metadata.distribution(package)
    for name in names:
        path = Path(distribution.locate_file(name))
        files[name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
print(json.dumps({"python": sys.version, "executable": sys.executable,
    "python_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
    "stdlib": sysconfig.get_path("stdlib"), "kernel": platform.release(),
    "packages": packages, "source_files": files, "bwrap": shutil.which("bwrap"),
    "libseccomp_exists": Path("/lib/x86_64-linux-gnu/libseccomp.so.2").is_file(),
    "model_imported": False, "dataset_loaded": False}, indent=2))
