"""Synthetic actual-image integration; no Task, model or dataset construction."""
import dataclasses
import importlib
import json
from pathlib import Path
import time
from types import SimpleNamespace

import anyio
from inspect_ai.util._sandbox.context import sandbox_default_context_var, sandbox_environments_context_var

import ptb_python_sandbox as sandbox

output = Path("/home/ben/observations.json")
observations = []

def retain(case, function):
    before = time.monotonic()
    try:
        value = function()
        row = {"case": case, "returned": dataclasses.asdict(value)}
    except Exception as exc:
        row = {"case": case, "raised": type(exc).__name__, "message": str(exc),
               "report": getattr(exc, "report", None)}
    row["elapsed_seconds"] = time.monotonic() - before
    observations.append(row)
    output.write_text(json.dumps(observations, indent=2) + "\n")
    print(json.dumps({"case": case, "raised": row.get("raised"),
                      "success": row.get("returned", {}).get("success"),
                      "elapsed_seconds": row["elapsed_seconds"]}), flush=True)
    return row

runtime = sandbox.build_runtime(
    bwrap="/opt/ptb-bwrap/bwrap", python="/usr/bin/python3.10",
    stdlib="/usr/lib/python3.10", library_dirs=["/lib/x86_64-linux-gnu", "/lib64"],
    public_packages=["/usr/local/lib/python3.10/dist-packages/numpy",
                     "/usr/local/lib/python3.10/dist-packages/numpy.libs",
                     "/usr/local/lib/python3.10/dist-packages/numpy-2.2.6.dist-info"],
)
Path("/home/ben/runtime.json").write_text(json.dumps(dataclasses.asdict(runtime), indent=2) + "\n")
good = retain("ordinary_algorithm", lambda: sandbox.execute_python(
    "import statistics\nassert statistics.median([9,2,5,1,8])==5\nprint('algorithm-ok')", runtime))
assert good.get("returned", {}).get("success") is True
good = retain("public_numpy", lambda: sandbox.execute_python(
    "import numpy as np\na=np.arange(9).reshape(3,3)\nassert int(np.trace(a))==12\nprint('numpy-ok')", runtime))
assert good.get("returned", {}).get("success") is True
private = """import os
from pathlib import Path
assert os.getpid()==1
assert os.getenv('PTB_FAKE_SECRET_FOR_TEST') is None
assert not Path('/home/ben/parent-only.txt').exists()
assert not Path('/home/ben/acceptance/ptb_python_sandbox.py').exists()
assert not Path('/dev/nvidia0').exists()
print('visibility-ok')
"""
good = retain("private_environment_and_files", lambda: sandbox.execute_python(private, runtime))
assert good.get("returned", {}).get("success") is True
bad = retain("wrong_generated_import", lambda: sandbox.execute_python(
    "print('preserve-before-import',flush=True)\nimport nonexistent_ordinary_program_module_2861", runtime))
assert bad.get("returned", {}).get("success") is False and "raised" not in bad
assert "preserve-before-import" in bad["returned"]["stdout"]
assert "ModuleNotFoundError" in bad["returned"]["stderr"]
timed = retain("owned_program_timeout", lambda: sandbox.execute_python(
    "import time\nprint('before-timeout',flush=True)\ntime.sleep(3)", runtime,
    limits=sandbox.Limits(wall_seconds=.4)))
assert timed.get("raised") == "TimeoutError"
assert timed["report"]["monitor_reaped"] and timed["report"]["descendants_reaped"]

async def check_adapter():
    cls = sandbox.register_inspect(runtime)
    envs = await cls.sample_init("invented-function-only", None, {})
    token = sandbox_environments_context_var.set(envs)
    default = sandbox_default_context_var.set("default")
    module = importlib.import_module("inspect_evals.humaneval.humaneval")
    state = SimpleNamespace(output=SimpleNamespace(completion="    return sorted((a,b))\n"),
        metadata={"prompt":"def arrange(a,b):\n", "entry_point":"arrange",
                  "test":"def check(fn):\n    assert fn(9,3)==[3,9]\n    assert fn(-1,4)==[-1,4]\n"})
    scores = []
    try:
        scorer = module.verify()
        for code in ["    return sorted((a,b))\n", "    return [a,b]\n",
                     "    import nonexistent_ordinary_program_module_2861\n"]:
            state.output.completion = code
            scores.append((await scorer(state, None)).value)
        assert scores == ["C", "I", "I"]
    finally:
        sandbox_default_context_var.reset(default)
        sandbox_environments_context_var.reset(token)
        await cls.sample_cleanup("invented-function-only", None, envs, False)
    Path("/home/ben/adapter.json").write_text(json.dumps({"scores": scores,
        "evidence": envs["default"].execution_evidence, "benchmark_dataset_loaded": False}, indent=2)+"\n")
    print(json.dumps({"native_scorer_synthetic_scores":scores}), flush=True)

anyio.run(check_adapter)
