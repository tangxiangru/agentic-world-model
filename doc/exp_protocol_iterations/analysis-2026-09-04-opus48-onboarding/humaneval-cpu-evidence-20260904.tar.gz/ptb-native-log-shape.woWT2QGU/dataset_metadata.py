"""Trusted data provisioning check; emits hashes/counts/dependency names only."""
import ast
import json
from pathlib import Path
import sys
sys.path.insert(0, "/opt/ptb-humaneval")
import task as profile

rows = profile.load_rows("/opt/hf")
native = profile.upstream_module()
samples = [native.record_to_sample()(row) for row in rows]
contract = profile.selection_contract(samples)
imports = set()
parse_failures = 0
dynamic_import_calls = 0
for row in rows:
    # The task inputs and verification tests only. Never execute or emit code.
    for column in ("prompt", "test"):
        try:
            tree = ast.parse(row[column])
        except SyntaxError:
            parse_failures += 1
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.update(item.name.split(".")[0] for item in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module.split(".")[0])
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "__import__":
                dynamic_import_calls += 1
summary = {"rows": len(rows), "source_sha256": profile.SOURCE_SHA256,
           "selection_sha256": profile.canonical_hash(contract),
           "prompt_test_import_roots": sorted(imports), "parse_failures": parse_failures,
           "explicit_dynamic_import_calls": dynamic_import_calls,
           "canonical_solution_inspected_for_dependencies": False,
           "dataset_code_executed": False, "model_called": False}
Path("/home/ben/dataset-metadata.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
