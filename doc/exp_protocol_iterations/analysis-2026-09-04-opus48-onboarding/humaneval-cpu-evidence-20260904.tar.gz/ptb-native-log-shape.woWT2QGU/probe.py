"""Real pinned logger and original scorer, invented samples, no code execution."""
import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/opt/ptb-humaneval")
import official_evidence as evidence
import task as profile
from inspect_ai import Task, eval as inspect_eval
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.solver import generate
from inspect_ai.util import ExecResult, SandboxEnvironment, sandboxenv


@sandboxenv(name="synthetic_no_execution")
class SyntheticBackend(SandboxEnvironment):
    @classmethod
    async def sample_init(cls, task_name, config, metadata):
        return {"default": cls()}

    @classmethod
    async def sample_cleanup(cls, task_name, config, environments, interrupted):
        pass

    async def exec(self, cmd, **kwargs):
        # Never execute cmd or interpret generated code. Tests only native log/scorer schema.
        return ExecResult(True, 0, "", "")

    async def write_file(self, *args, **kwargs):
        raise AssertionError("unexpected file write")

    async def read_file(self, *args, **kwargs):
        raise AssertionError("unexpected file read")


samples = [Sample(id=f"invented-{i}", input="invented input", target="invented target",
                  metadata={"prompt": "synthetic-only", "test": "synthetic-only", "entry_point": "invented"})
           for i in range(3)]
contract = profile.selection_contract(samples)
invocation = {"attempt_id": "native-log-shape-only", "model": "mockllm/model", "max_tokens": 37}
native = importlib.import_module("inspect_evals.humaneval.humaneval")
task = Task(name="humaneval", dataset=MemoryDataset(samples), epochs=1,
            solver=generate(), scorer=native.verify(), sandbox="synthetic_no_execution",
            metadata={"ptb_invocation": invocation, "ptb_selection_sha256": evidence.digest(contract)})
logs = inspect_eval(task, model="mockllm/model", max_tokens=37, max_connections=1,
                    log_dir="/home/ben/logs", log_format="json", log_realtime=False,
                    score_display=False, fail_on_error=True)
assert len(logs) == 1
location = Path(logs[0].location)
raw = json.loads(location.read_text())
summary = {"raw_log": str(location), "status": raw["status"],
           "eval_config": raw["eval"]["config"], "generate_config": raw["eval"]["model_generate_config"],
           "results": raw["results"], "sample_score_keys": list(raw["samples"][0]["scores"]),
           "real_model_called": False, "generated_code_executed": False, "benchmark_dataset_loaded": False}
Path("/home/ben/shape.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
checked = evidence.publish_metrics(log_path=location, metrics_path="/home/ben/metrics.json",
                                   contract=contract, invocation=invocation)
assert evidence.validate_published("/home/ben/metrics.json", expected_contract=contract,
                                   expected_invocation=invocation)["scored_samples"] == 3
print("NATIVE LOG SHAPE AND PUBLICATION PASSED")
