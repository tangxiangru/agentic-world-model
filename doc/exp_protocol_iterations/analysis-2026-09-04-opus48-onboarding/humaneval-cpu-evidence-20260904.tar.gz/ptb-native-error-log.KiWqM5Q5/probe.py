"""Expected policy failure must remain a failed eval with structured raw evidence."""
import importlib
import json
from pathlib import Path
import sys
sys.path.insert(0, "/opt/ptb-humaneval")
import official_evidence as evidence
import runtime
import task as profile
from inspect_ai import Task, eval as inspect_eval
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.model import ModelOutput
from inspect_ai.solver import generate

root = Path("/home/ben")
record = runtime.register_backend(root, image_reference="vllm_debug.sif",
    image_sha256="72748f77f9fe5a1abe925bb532c1da64d80b1dcce7849179c9546700099448f8")
native = importlib.import_module("inspect_evals.humaneval.humaneval")
sample = Sample(id="invented-policy-failure", input="invented-only", target="not executed",
                metadata={"prompt": "def invented():\n", "entry_point": "invented",
                          "test": "def check(fn):\n    fn()\n"})
contract = profile.selection_contract([sample])
invocation = {"attempt_id": "native-error-only", "model": "mockllm/model", "max_tokens": 37,
              "sandbox_runtime_sha256": record["runtime_sha256"],
              "sandbox_helper_sha256": record["helper_sha256"]}
task = Task(name="humaneval", dataset=MemoryDataset([sample]), epochs=1, solver=generate(),
            scorer=native.verify(), sandbox="ptb_python",
            metadata={"ptb_invocation": invocation, "ptb_selection_sha256": evidence.digest(contract)})
output = ModelOutput.from_content(model="mockllm/model", content=(
    "    print('before-policy-denial',flush=True)\n    import ctypes\n    ctypes.CDLL(None).unshare(0x10000000)\n"))
logs = inspect_eval(task, model="mockllm/model", model_args={"custom_outputs": [output]}, max_tokens=37,
                    max_connections=1, log_dir=str(root / "logs"), log_format="json",
                    log_realtime=False, log_samples=True, log_buffer=1, fail_on_error=True, score_display=False)
assert len(logs) == 1
raw_path = Path(logs[0].location)
raw = evidence.strict_json(raw_path.read_bytes())
assert raw["status"] == "error"
report = raw["samples"][0]["store"]["ptb_python_execution"][0]
assert report["outcome"] == "dependency_error" and report["error_category"] == "policy_denied"
assert report["monitor_reaped"] and report["descendants_reaped"]
assert "before-policy-denial" in report["output"]["stdout"]["text"]
try:
    evidence.publish_metrics(log_path=raw_path, metrics_path=root / "metrics.json",
                             contract=contract, invocation=invocation)
except evidence.EvidenceError:
    pass
else:
    raise AssertionError("failed executor must not publish a model-quality score")
assert not (root / "metrics.json").exists()
summary = {"status": raw["status"], "structured_outcome": report["outcome"],
           "category": report["error_category"], "cleanup_confirmed": True,
           "partial_stdout_retained": True, "metrics_published": False,
           "real_model_called": False, "benchmark_data_loaded": False, "raw_log": str(raw_path)}
(root / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
print(json.dumps(summary, indent=2))
print("NATIVE ERROR LOG RETENTION PASSED")
