"""Only public-file mount probes; no benchmark/model/generated code."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

base = Path('/home/ben')
source = Path('/usr/lib/x86_64-linux-gnu/libbz2.so.1.0.4').resolve(strict=True)
copy = base / 'copied-libbz2.so'
payload = source.read_bytes()
copy.write_bytes(payload)
assert copy.read_bytes() == payload

def metadata(path):
    st = path.stat()
    matches = []
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        mount = line.split()[4]
        if str(path) == mount or str(path).startswith(mount.rstrip('/') + '/'):
            matches.append(line)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'device': st.st_dev, 'inode': st.st_ino,
            'mount': max(matches, key=lambda item: len(item.split()[4]))}

common = ['/opt/ptb-bwrap/bwrap', '--unshare-all', '--as-pid-1', '--die-with-parent',
          '--new-session', '--cap-drop', 'ALL', '--cap-add', 'CAP_SYS_ADMIN',
          '--cap-add', 'CAP_SETPCAP', '--clearenv']
observations = []
for label, public, target in [
    ('image_file_alias_target', source, '/lib/x86_64-linux-gnu/libbz2.so.1.0'),
    ('image_file_simple_target', source, '/public-file'),
    ('copied_file_alias_target', copy, '/lib/x86_64-linux-gnu/libbz2.so.1.0'),
    ('copied_file_simple_target', copy, '/public-file'),
]:
    cmd = common + ['--ro-bind', str(public), target, '--', '/intentionally-missing-command']
    result = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=10,
                            env={'PATH':'/usr/bin:/bin', 'LC_ALL':'C'})
    observations.append({'case': label, 'source': metadata(public), 'command':cmd,
        'returncode': result.returncode, 'stdout':result.stdout, 'stderr':result.stderr})
    print(json.dumps(observations[-1]), flush=True)
    (base / 'mount-probe.json').write_text(json.dumps(observations, indent=2)+'\n')
