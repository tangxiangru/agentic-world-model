# Nested Apptainer / bwrap CPU acceptance, 2026-09-04

Only invented programs and public runtime files; no dataset, benchmark item/gold,
model, inference, GPU, Slurm, package installation or network request.
The original parent failure artifacts under `/tmp/ptb-vllm-cpu-accept-cXcFpdnx`
were read-only and remain untouched.

`mount-probe.json` holds four minimal probes with identical inner isolation
flags. The image's libbz2 source is on `fuse.fuse-overlayfs` marked `unbindable`:
both original and simple destination names fail with EINVAL. Its identical
`5e516f77fc36dd924fdf02c8489a217f55fa1548883d32c3a5e041fb25d47d6e`
copy on the task-home ext4 bind mounts correctly at both targets. The later
intentional missing-command error proves the bind step completed; it is not a
successful generated program and was never counted as a model score.

Final tested helper SHA256:
`94f41494e049d6a1e2e40c2057f25b205356eff72c343b13ef47e9b550035da7`.
The helper is explicitly bound read-only; only its selected public-file closure
is exposed to generated Python. No inner isolation flag was removed.

Exact actual-image replay (requires explicit namespace execution permission):

```bash
LD_LIBRARY_PATH=/rmeng_data/robtang/tools/apt-root/usr/lib/x86_64-linux-gnu \
/rmeng_data/robtang/tools/apt-root/usr/bin/apptainer exec \
  --containall --cleanenv \
  --home /tmp/ptb-nested-mount.n7oNq5y5:/home/ben --pwd /home/ben \
  --bind /home/robtang_google_com/.local/bin/bwrap:/opt/ptb-bwrap/bwrap:ro \
  --bind /tmp/ptb-opus48-onboarding-oGLZFUf4/repo/src/eval/ptb_python_sandbox.py:/home/ben/ptb_python_sandbox.py:ro \
  --env PTB_FAKE_SECRET_FOR_TEST=synthetic-only \
  --env PYTHONDONTWRITEBYTECODE=1 --writable-tmpfs \
  /rmeng_data/robtang/ptb-containers/vllm_debug.sif \
  python3.10 /home/ben/probe_materialized.py
```

For the minimal mount comparison use the same command ending in
`python3.10 /home/ben/probe_mount.py` (the helper bind is unnecessary there).
The synthetic environment value is deliberately not a real credential. No `--nv`.

Final replay: `MATERIALIZED_IMAGE_ACCEPTANCE_OK`; 13 recorded cases, including
expected rejection paths and a metadata row, not 13 benchmark scores. Raw data
are `materialized-observations.json` and `materialized-runtime.json`.
Final transport is `verified-public-ryssa845/runtime`, receipt SHA256
`d8fbd4c61c6ca753016d415c33afa795e1d766e19e050ea461d7064fd47654b6`.
Original public Runtime remains
`01d60204dd8b6023e9177c3c27f0cf0ac882ad1306073f67d17695f92c652178`;
transport Runtime is separately
`546db79f4fc54d2d3f039f2bbcde63b593ffc60c6239e6a290a162b147af0df0`.
The image SHA is retained from caller provenance, not rehashed inside the image.
Original source and transported file bytes/modes are verified on every use.

Current observations SHA256:
`54303ddcbafcb888b09d041cf43023049a92c9e86dd58adadbceebff27d2969f`.
Probe source hashes: mount
`a3853cb47a483ed7231c0dfd76fb492556f3a76d4b402b66e37338ff186febc9`,
materialized execution
`b356e7f35b820e8688570d6165e7e181fc785562313516c7fedee9b148f9bcc7`.

The earlier `verified-public-7bwb5ugx` transport is retained, not overwritten.
Replay creates a fresh transport but replaces this directory's diagnostic JSON
outputs; archive them first if preserving this exact replay. Neither transport
contains model weights or benchmark data. Nothing was recursively removed.
Compute-node permissions, GPU-enabled outer mounts, full public dependency
parity, whole-task/model execution and official log integration remain separate
acceptance responsibilities.
