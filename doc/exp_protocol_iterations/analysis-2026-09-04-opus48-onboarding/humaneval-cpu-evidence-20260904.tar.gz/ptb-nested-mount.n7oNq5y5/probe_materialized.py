"""Actual vllm_debug CPU/public-runtime acceptance; invented programs only."""
import dataclasses
import hashlib
import importlib
import json
import os
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace

import anyio
import ptb_python_sandbox as sandbox

base = Path('/home/ben')
records = []

def keep(case, action):
    started = time.monotonic()
    try:
        value = action()
        row = {'case': case, 'value': dataclasses.asdict(value) if dataclasses.is_dataclass(value) else value}
    except Exception as exc:
        row = {'case': case, 'raised':type(exc).__name__, 'message':str(exc), 'report':getattr(exc,'report',None)}
    row['elapsed_seconds'] = time.monotonic()-started
    records.append(row)
    (base/'materialized-observations.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({'case':case,'raised':row.get('raised'),'elapsed_seconds':row['elapsed_seconds']}),flush=True)
    return row

original = sandbox.build_runtime(bwrap='/opt/ptb-bwrap/bwrap', python='/usr/bin/python3.10',
    stdlib='/usr/lib/python3.10', library_dirs=['/lib/x86_64-linux-gnu','/lib64'],
    public_packages=['/usr/local/lib/python3.10/dist-packages/numpy',
        '/usr/local/lib/python3.10/dist-packages/numpy.libs',
        '/usr/local/lib/python3.10/dist-packages/numpy-2.2.6.dist-info'])
parent = Path(tempfile.mkdtemp(prefix='verified-public-',dir=base))
before = time.monotonic()
runtime = sandbox.materialize_runtime(original, directory=parent/'runtime',
    source_image_reference='/rmeng_data/robtang/ptb-containers/vllm_debug.sif',
    source_image_sha256='72748f77f9fe5a1abe925bb532c1da64d80b1dcce7849179c9546700099448f8')
(base/'materialized-runtime.json').write_text(json.dumps(dataclasses.asdict(runtime),indent=2)+'\n')
keep('identities',lambda:{'source_runtime_sha256':original.identity,'transport_runtime_sha256':runtime.identity,
    'materialization':runtime.materialization,'materialize_seconds':time.monotonic()-before,
    'python_sha256':hashlib.sha256(Path('/usr/bin/python3.10').read_bytes()).hexdigest(),
    'evaluator_pid_namespace':os.readlink('/proc/self/ns/pid')})

for name, code in [
    ('median',"import statistics; assert statistics.median([9,2,5,1,8])==5; print('median-ok')"),
    ('numpy',"import numpy as np; assert float(np.linalg.det(np.eye(3)))==1; print(np.__version__)"),
    ('visibility',"import os; from pathlib import Path; assert os.getpid()==1; assert os.getenv('PTB_FAKE_SECRET_FOR_TEST') is None; assert not Path('/home/ben/materialized-runtime.json').exists(); assert not Path('/home/ben/ptb_python_sandbox.py').exists(); assert not Path('/dev/nvidia0').exists(); print('private')"),
    ('concurrency',"import threading,subprocess,sys; values=[]; t=threading.Thread(target=lambda: values.append(1)); t.start(); t.join(); assert values==[1]; assert subprocess.check_output([sys.executable,'-c','print(17)']).strip()==b'17'"),
]:
    row = keep(name,lambda code=code:sandbox.execute_python(code,runtime))
    assert row.get('value',{}).get('success'),row

row = keep('missing_import',lambda:sandbox.execute_python("print('partial',flush=True); import absent_synthetic_public_module_423",runtime))
assert row['value']['returncode']==1 and row['value']['stdout']=='partial\n'
row = keep('timeout',lambda:sandbox.execute_python("import os,time; print('timed',flush=True); p=os.fork(); time.sleep(10)",runtime,limits=sandbox.Limits(wall_seconds=.3)))
assert row['raised']=='TimeoutError' and row['report']['descendants_reaped']
assert not Path('/proc') .joinpath(str(row['report']['namespace_child_pid'])).exists()
row = keep('policy_denial',lambda:sandbox.execute_python("import ctypes; ctypes.CDLL(None).unshare(0x10000000)",runtime))
assert row['raised']=='SandboxDependencyError'

async def scorer_check():
    from inspect_ai.util._sandbox.context import sandbox_default_context_var,sandbox_environments_context_var
    cls = sandbox.register_inspect(runtime,name='ptb_materialized_image_probe')
    envs = await cls.sample_init('invented-only',None,{})
    token = sandbox_environments_context_var.set(envs)
    default = sandbox_default_context_var.set('default')
    module = importlib.import_module('inspect_evals.humaneval.humaneval')
    state = SimpleNamespace(output=SimpleNamespace(completion=''),metadata={
        'prompt':'def arrange(a,b):\n','entry_point':'arrange',
        'test':'def check(fn):\n    assert fn(9,3)==[3,9]\n'})
    scores=[]
    try:
        score=module.verify()
        for code in ['    return sorted((a,b))\n','    return [a,b]\n','    import absent_synthetic_public_module_423\n']:
            state.output.completion=code
            scores.append((await score(state,None)).value)
        assert scores==['C','I','I']
        return {'scores':scores,'evidence':envs['default'].execution_evidence,'dataset_loaded':False}
    finally:
        sandbox_default_context_var.reset(default)
        sandbox_environments_context_var.reset(token)
        await cls.sample_cleanup('invented-only',None,envs,False)

row=keep('original_scorer',lambda:anyio.run(scorer_check))
assert row.get('value',{}).get('scores')==['C','I','I']

target=Path(runtime.files[0][0]); saved_bytes=target.read_bytes(); saved_mode=target.stat().st_mode&0o777
target.chmod(0o600); target.write_bytes(b'changed public transport bytes'); target.chmod(saved_mode)
row=keep('changed_copy_rejected',lambda:sandbox.execute_python("raise AssertionError('must never run')",runtime))
assert row['raised']=='SandboxInfrastructureError' and not row['report'].get('started')
target.chmod(0o600); target.write_bytes(saved_bytes); target.chmod(saved_mode)
backup=target.with_name(target.name+'.saved'); target.rename(backup); target.symlink_to(backup)
row=keep('symlink_copy_rejected',lambda:sandbox.execute_python("raise AssertionError('must never run')",runtime))
assert row['raised']=='SandboxInfrastructureError'
target.unlink(); backup.rename(target)

receipt_path=Path(runtime.materialization['receipt']); saved_receipt=receipt_path.read_bytes()
receipt=json.loads(saved_receipt)
receipt['source_runtime']['files'][0][0]=str(target) # byte-identical but no longer original image path
receipt_path.write_text(json.dumps(receipt))
changed=dataclasses.replace(runtime,materialization={**runtime.materialization,'sha256':sandbox._sha(receipt_path)})
row=keep('source_path_substitution_rejected',lambda:sandbox.execute_python("raise AssertionError('must never run')",changed))
assert row['raised']=='SandboxInfrastructureError' and 'original public runtime identity' in row['message']
receipt_path.write_bytes(saved_receipt)
runtime.verify()
row=keep('existing_destination_rejected',lambda:sandbox.materialize_runtime(original,directory=parent/'runtime',
    source_image_reference='same-image',source_image_sha256='72748f77f9fe5a1abe925bb532c1da64d80b1dcce7849179c9546700099448f8'))
assert row['raised']=='SandboxInfrastructureError'
print('MATERIALIZED_IMAGE_ACCEPTANCE_OK',flush=True)
