"""Native Inspect+original verify+real isolated backend; invented programs only."""
import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/opt/ptb-humaneval")
import official_evidence as evidence
import runtime
import task as profile
from inspect_ai import Task, eval as inspect_eval
from inspect_ai.dataset import MemoryDataset, Sample
from inspect_ai.model import ModelOutput
from inspect_ai.solver import generate

root = Path("/home/ben")
record = runtime.register_backend(root, image_reference="vllm_debug.sif",
    image_sha256="72748f77f9fe5a1abe925bb532c1da64d80b1dcce7849179c9546700099448f8")
native = importlib.import_module("inspect_evals.humaneval.humaneval")
cases = {
    "invented-good": "    return sorted((a,b))\n",
    "invented-wrong": "    return [a,b]\n",
    "invented-import": "    print('before-import',flush=True)\n    import nonexistent_invented_module_8421\n",
    "invented-timeout": "    import time\n    print('before-timeout',flush=True)\n    time.sleep(40)\n",
}
samples = [Sample(id=case, input=case, target="synthetic target not executed",
                  metadata={"prompt": "def arrange(a,b):\n", "entry_point": "arrange",
                            "test": "def check(fn):\n    assert fn(9,3)==[3,9]\n"})
           for case in cases]
contract = profile.selection_contract(samples)
invocation = {"attempt_id": "native-sandbox-log-only", "model": "mockllm/model", "max_tokens": 37,
              "sandbox_runtime_sha256": record["runtime_sha256"],
              "sandbox_helper_sha256": record["helper_sha256"], "sandbox_limits": record["limits"]}

def output(input, *_):
    return ModelOutput.from_content(model="mockllm/model", content=cases[input[-1].text])

task = Task(name="humaneval", dataset=MemoryDataset(samples), epochs=1, solver=generate(),
            scorer=native.verify(), sandbox="ptb_python",
            metadata={"ptb_invocation": invocation, "ptb_selection_sha256": evidence.digest(contract)})
logs = inspect_eval(task, model="mockllm/model", model_args={"custom_outputs": output}, max_tokens=37,
                    max_connections=1, max_samples=1, log_dir=str(root / "logs"), log_format="json",
                    log_realtime=False, log_samples=True, log_buffer=1, fail_on_error=True, score_display=False)
assert len(logs) == 1
raw_path = Path(logs[0].location)
raw = evidence.strict_json(raw_path.read_bytes())
rows = [{"id": sample["id"], "score": (sample.get("scores") or {}).get("verify", {}).get("value"),
         "error": bool(sample.get("error")),
         "executions": len((sample.get("store") or {}).get("ptb_python_execution", []))}
        for sample in raw.get("samples", [])]
summary = {"status": raw["status"], "rows": rows, "raw_log": str(raw_path),
           "real_model_called": False, "benchmark_data_loaded": False}
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
published = evidence.publish_metrics(log_path=raw_path, metrics_path=root / "metrics.json",
                                    contract=contract, invocation=invocation)
assert published["accuracy"] == .25
assert evidence.validate_published(root / "metrics.json", expected_contract=contract,
                                   expected_invocation=invocation)["scored_samples"] == 4
print("NATIVE SANDBOX LOG PUBLICATION PASSED")
